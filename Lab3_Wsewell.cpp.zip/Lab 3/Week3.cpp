#include<iostream>
using namespace std;

/**
 * @file Lab3_Wsewell.cpp
 * @author Winston Sewell
 * @date 2025-01-29
 * @brief A menu-driven program to calculate areas of rectangles and circles.
 */

int main()
{
    float length, width;
    float R_Area = length * width;
    int choice = 0;
    const double Pi = 3.14159;
    float C_Area = Pi * (length * length);
    std::cout <<"1. Caclulate the area of a Rectangle"<<std::endl;
    std::cout <<"2. Caclulate the area of a Circle"<<std::endl;
    std::cout <<"3. Quit The Program"<<std::endl;
    cin >> choice;
    if (choice == 1)
    {
        cout << "Please Enter The Length of A Rectangle: " ;
        cin >> length;
        cout << "Please Enter The Width of A Rectangle: ";
        cin >> width;
        cout << "the Area is : " << R_Area << endl;

    }

    if (choice == 2)
    {
        cout << "Please Enter The Radius: ";
        cin >> length;
        cout << "The Area is: " <<C_Area << endl;

    }

    else
    {
        return 0;
    }


}