#include <iostream>
using namespace std;
/**
 * @file Lab4_Wsewell.cpp
 * @author Winston Sewell
 * @date 2025-02-05
 * @brief A program to generate a multiplication table with input validation.
 */

int main()
{
int Max_num = 0;
int i = 0;
int j = 1;


while (true)
{
    cout << "Please Enter the Maxium Digit for the multiplication Table " << endl;
    cout << "The digit must be greater than 4 and less than 10" << endl;
    cin >> Max_num;

    if ((Max_num > 4) && (Max_num < 10))
    {
        while (i < Max_num)
        {
           while (j < Max_num)
           {
            cout << "" <<j * Max_num<< endl;
            j++;
           }

           i++;
           
        }
        
    }

    else
    {
        cout << "Error! Please Enter a number greater than 4 and less than 10: " << endl;
    }
    
}


return 0;
}