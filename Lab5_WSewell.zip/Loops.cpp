#include <iostream>
using namespace std;
/**
 * @file Lab5_Wsewell.cpp
 * @author Winston Sewell
 * @date 2025-02-12
 * @brief A program to generate a multiplication table with input validation.
 */

int main()
{
int Max_num = 0;
int i = 1;
int j = 1;
int counter = 0;

void printInputValidationError();
void ismaxDigitalInputValid(int input);
int getMaxDigitInput;

cout << "Please Enter the Maxium Digit for the multiplication Table " << endl;
cout << "The digit must be greater than 4 and less than 10" << endl;

while (counter <= Max_num)
{
    cin >> Max_num;
    ismaxDigitalInputValid(Max_num);

    while (i <= Max_num)
    {
            cout << "" << i * j << endl;
            i++;
    }
    counter++;
    j++; 
    
} 

return 0;
}

void printInputValidationError()
{
    cout << "Error! Please Enter a number greater than 4 and less than 10: " << endl;
}

void ismaxDigitalInputValid(int input)
{
    if (input > 4 && input < 10)
    {
        cout << "You rock";
        return;
    }

    else
    {
        printInputValidationError();
    }
    
}
